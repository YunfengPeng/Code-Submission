import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 

from sklearn.metrics import confusion_matrix, zero_one_loss, precision_score, recall_score, f1_score
from sklearn.metrics import matthews_corrcoef, cohen_kappa_score
from sklearn.model_selection import train_test_split
from sklearn import preprocessing

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, Activation, LSTM, Bidirectional, Conv1D
from tensorflow.keras.layers import BatchNormalization, MaxPooling1D, Reshape, Concatenate, Multiply
from tensorflow.keras.utils import to_categorical
import tensorflow as tf


# 加载数据
raw_data_filename = "data/expendData/CIC-IDS2017_extend.csv"
print("Loading raw data...")
raw_data = pd.read_csv(raw_data_filename, header=None, low_memory=False)

# 随机抽取比例
raw_data = raw_data.sample(frac=0.03)

# 将非数值型的数据转换为数值型数据
last_column_index = raw_data.shape[1] - 1
raw_data[last_column_index], attacks = pd.factorize(raw_data[last_column_index], sort=True)

# 对原始数据进行切片，分离出特征和标签
features = raw_data.iloc[:, :raw_data.shape[1] - 1]  # 特征
labels = raw_data.iloc[:, raw_data.shape[1] - 1:]    # 标签

# 特征数据标准化"符合正太分布"
features = preprocessing.scale(features)
features = pd.DataFrame(features)

# 将多维的标签转为一维的数组
labels = labels.values.ravel()

df = pd.DataFrame(features)
# 将数据分为训练集和测试集(按类别分类)
X_train, X_test, y_train, y_test = train_test_split(df, labels, train_size=0.7, test_size=0.3, stratify=labels)
#X_train, X_test, y_train, y_test = train_test_split(features, labels, train_size=0.7, test_size=0.3, str1tify=None)

# 转换为 one-hot 编码
num_classes = len(np.unique(y_train))  # 获取类别数
y_train = to_categorical(y_train, num_classes=num_classes)
y_test = to_categorical(y_test, num_classes=num_classes)

# 标签映射字典
class_map = {
    0: "BENIGN",
    1: "Bot",
    2: "DDoS",
    3: "DoS GoldenEye",
    4: "DoS Hulk",
    5: "DoS Slowhttptest",
    6: "DoS slowloris",
    7: "FTP-Patator",
    8: "Heartbleed",
    9: "Infiltration",
    10: "PortScan",
    11: "SSH-Patator",
    12: "Brute Force",
    13: "Sql Injection",
    14: "XSS"
}

# 定义注意力机制层
def attention_weights(inputs, num_filters):
    """
    计算注意力权重
    inputs: 输入的卷积层输出
    num_filters: 卷积层输出的通道数
    """
    # 计算注意力得分（使用Dense层）
    attention_score = Dense(1, activation='sigmoid')(inputs)
    attention_score = Reshape((-1,))(attention_score)  # 转换为向量形式
    attention_weights = tf.nn.softmax(attention_score, axis=-1)  # 对每个特征图的权重进行softmax归一化
    return attention_weights
from tcn import TCN
# 新的build_model函数（融合了注意力机制）
def build_model(input_shape, num_classes):
    inputs = Input(shape=input_shape)

    # 使用不同大小的卷积核：3、7、9
    conv3 = Conv1D(60, kernel_size=3, padding="same", activation="relu")(inputs)
    conv7 = Conv1D(60, kernel_size=7, padding="same", activation="relu")(inputs)
    conv9 = Conv1D(60, kernel_size=9, padding="same", activation="relu")(inputs)

    # 为每个卷积层的输出应用注意力机制
    attention_3 = attention_weights(conv3, 60)
    attention_7 = attention_weights(conv7, 60)
    attention_9 = attention_weights(conv9, 60)

    # 扩展 attention 的维度，使其形状与卷积输出兼容
    attention_3 = tf.expand_dims(attention_3, axis=-1)  # 形状变为 (batch_size, sequence_length, 1)
    attention_7 = tf.expand_dims(attention_7, axis=-1)
    attention_9 = tf.expand_dims(attention_9, axis=-1)

    # 加权卷积输出
    conv3_weighted = Multiply()([conv3, attention_3])
    conv7_weighted = Multiply()([conv7, attention_7])
    conv9_weighted = Multiply()([conv9, attention_9])

    # 合并加权后的卷积输出
    concatenated = tf.concat([conv3_weighted, conv7_weighted, conv9_weighted], axis=-1)

    # 后续的卷积池化、LSTM层等处理
    x = MaxPooling1D(pool_size=5)(concatenated)  # 池化层
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(60, return_sequences=False))(x)  # 第一个BiLSTM层
    x = Reshape((120, 1))(x)  # 重塑张量形状
    x = MaxPooling1D(pool_size=5)(x)  # 第二层池化
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(130, return_sequences=False))(x)  # 第二个BiLSTM层
    x = Dropout(0.52)(x)  # Dropout防止过拟合

    # 输出层，类别数为 num_classes
    x = Dense(num_classes)(x)
    x = Activation('softmax')(x)  # Softmax激活函数

    # 定义模型
    model = Model(inputs=inputs, outputs=x)
    model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=0.0013),
                  metrics=['accuracy'])
    return model



# 数据调整为三维形状
X_train_reshaped = X_train.values.reshape(-1, X_train.shape[1], 1)
X_test_reshaped = X_test.values.reshape(-1, X_test.shape[1], 1)

# 构建并训练模型
input_shape = (X_train.shape[1], 1)  # 训练数据的形状
model = build_model(input_shape, num_classes)

print("Training model...")
model.fit(X_train_reshaped, y_train, epochs=50, batch_size=64, validation_data=(X_test_reshaped, y_test), verbose=1)

# 预测
print("Predicting...")
y_pred = model.predict(X_test_reshaped)
y_pred = np.argmax(y_pred, axis=1)  # 将预测的结果转为类标签

# 计算性能指标
print("Computing performance metrics...")
results = confusion_matrix(np.argmax(y_test, axis=1), y_pred)
error = zero_one_loss(np.argmax(y_test, axis=1), y_pred)

# 多分类指标
accuracy = np.sum(np.diag(results)) / np.sum(results)  # 正确分类的样本数 / 总样本数
precision = precision_score(np.argmax(y_test, axis=1), y_pred, average='weighted', zero_division=0)
recall = recall_score(np.argmax(y_test, axis=1), y_pred, average='weighted', zero_division=0)
f1 = f1_score(np.argmax(y_test, axis=1), y_pred, average='weighted', zero_division=0)

# FPR 和 FNR
FP = results.sum(axis=0) - np.diag(results)
FN = results.sum(axis=1) - np.diag(results)
TN = results.sum() - (FP + FN + np.diag(results))
TP = np.diag(results)

FPR = FP / (FP + TN + 1e-10)
FNR = FN / (FN + TP + 1e-10)

# MCC 和 Kappa
mcc = matthews_corrcoef(np.argmax(y_test, axis=1), y_pred)
kappa = cohen_kappa_score(np.argmax(y_test, axis=1), y_pred)

print("Metrics computed:")
print(f"Multi-class Accuracy(ACC): {accuracy:.4f}")
print(f"Multi-class Precision(PR): {precision:.4f}")
print(f"Multi-class Recall: {recall:.4f}")
print(f"Multi-class F1 Score(F1): {f1:.4f}")
print(f"FPR: {np.mean(FPR):.4f}")
print(f"FNR: {np.mean(FNR):.4f}")
print(f"MCC: {mcc:.4f}")
print(f"Kappa: {kappa:.4f}")

# 获取类别名称
class_labels = [class_map[i] for i in range(num_classes)]  # 使用 class_map 进行标签映射

# 绘制混淆矩阵概率图
cm_prob = results.astype('float32') / results.sum(axis=1)[:, np.newaxis]
plt.figure(figsize=(14, 10))
ax = sns.heatmap(cm_prob, annot=True, fmt='.3f', cmap='Blues', cbar=True, xticklabels=class_labels, yticklabels=class_labels)

# 设置边框可见
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.0)  # 边框粗细

plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.xticks(rotation=45)  # 设置X轴标签倾斜45度
plt.savefig('confusion_matrix_prob_based.eps', dpi=600, bbox_inches='tight')
plt.show()
