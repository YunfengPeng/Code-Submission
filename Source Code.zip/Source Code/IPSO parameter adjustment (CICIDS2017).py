import numpy as np
import tensorflow as tf
import pandas as pd
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, Activation, LSTM, Bidirectional, Conv1D
from tensorflow.keras.layers import BatchNormalization, MaxPooling1D, Reshape, Multiply


# ------------------- 数据预处理（保持和主模型一致）-------------------
raw_data_filename = "data/expendData/CIC-IDS2017_extend.csv"
raw_data = pd.read_csv(raw_data_filename, header=None, low_memory=False)
raw_data = raw_data.sample(frac=0.03)
last_column_index = raw_data.shape[1] - 1
raw_data[last_column_index], attacks = pd.factorize(raw_data[last_column_index], sort=True)
features = raw_data.iloc[:, :raw_data.shape[1] - 1]
labels = raw_data.iloc[:, raw_data.shape[1] - 1:]
features = preprocessing.scale(features)
features = pd.DataFrame(features)
labels = labels.values.ravel()
X_train, X_test, y_train, y_test = train_test_split(features, labels, train_size=0.7, test_size=0.3, stratify=labels)
num_classes = len(np.unique(y_train))
y_train = to_categorical(y_train, num_classes=num_classes)
y_test = to_categorical(y_test, num_classes=num_classes)
X_train_reshaped = X_train.values.reshape(-1, X_train.shape[1], 1)
X_test_reshaped = X_test.values.reshape(-1, X_test.shape[1], 1)
input_shape = (X_train.shape[1], 1)
print(input_shape)

# ------------------- 注意力权重层 -------------------
def attention_weights(inputs, num_filters):
    attention_score = Dense(1, activation='sigmoid')(inputs)
    attention_score = Reshape((-1,))(attention_score)
    attention_weights = tf.nn.softmax(attention_score, axis=-1)
    return attention_weights

# ------------------- 构建模型，支持所有超参数 -------------------
def build_model(input_shape, num_classes, filter_num, units1, units2, dropout, lr):
    filter_num = int(round(filter_num))  # 确保为整数
    units1 = int(round(units1))
    units2 = int(round(units2))

    inputs = Input(shape=input_shape)

    # 使用不同大小的卷积核：3、5、9
    conv3 = Conv1D(filter_num, kernel_size=3, padding="same", activation="relu")(inputs)
    conv7 = Conv1D(filter_num, kernel_size=5, padding="same", activation="relu")(inputs)
    conv5 = Conv1D(filter_num, kernel_size=9, padding="same", activation="relu")(inputs)

    # 为每个卷积层的输出应用注意力机制
    attention_3 = attention_weights(conv3, filter_num)
    attention_7 = attention_weights(conv7, filter_num)
    attention_5 = attention_weights(conv5, filter_num)

    # 扩展 attention 的维度，使其形状与卷积输出兼容
    attention_3 = tf.expand_dims(attention_3, axis=-1)
    attention_7 = tf.expand_dims(attention_7, axis=-1)
    attention_5 = tf.expand_dims(attention_5, axis=-1)

    # 加权卷积输出
    conv3_weighted = Multiply()([conv3, attention_3])
    conv7_weighted = Multiply()([conv7, attention_7])
    conv5_weighted = Multiply()([conv5, attention_5])

    # 合并加权后的卷积输出
    concatenated = tf.concat([conv3_weighted, conv7_weighted, conv5_weighted], axis=-1)

    # 后续的卷积池化、LSTM层等处理
    x = MaxPooling1D(pool_size=5)(concatenated)  # 池化层
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(units1, return_sequences=False))(x)  # 第一个BiLSTM层
    x = Reshape((2*units1, 1))(x)  # 重塑张量形状
    x = MaxPooling1D(pool_size=5)(x)  # 第二层池化
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(units2, return_sequences=False))(x)  # 第二个BiLSTM层
    x = Dropout(dropout)(x)  # Dropout防止过拟合

    # 输出层，类别数为 num_classes
    x = Dense(num_classes)(x)
    x = Activation('softmax')(x)  # Softmax激活函数

    # 定义模型
    model = Model(inputs=inputs, outputs=x)
    model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                  metrics=['accuracy'])
    return model


# ------------------- Levy飞行扰动 -------------------
def levy_flight(beta, dim):
    sigma_u = (np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) /
               (np.math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = np.random.randn(dim) * sigma_u
    v = np.random.randn(dim)
    step = u / (np.abs(v) ** (1 / beta))
    return step

def objective_function(params):
    filter_num = int(round(params[0]))  # 卷积过滤器数量
    units1 = int(round(params[1]))  # 第一个BiLSTM单元数量
    units2 = int(round(params[2]))  # 第二个BiLSTM单元数量
    dropout = float(params[3])  # Dropout比例
    lr = float(params[4])  # 学习率

    try:
        tf.keras.backend.clear_session()  # 清理之前的模型会话，释放内存
        model = build_model(input_shape, num_classes, filter_num, units1, units2, dropout, lr)  # 构建模型

        # 训练模型，epochs设置为50，可以根据需要调整
        hist = model.fit(X_train_reshaped, y_train, epochs=50, batch_size=64,
                         validation_data=(X_test_reshaped, y_test), verbose=1)

        # 获取测试集的损失（validation loss）
        val_loss = hist.history['val_loss'][-1]  # 获取最后一个epoch的测试集损失

        return val_loss  # 最小化测试集的loss

    except Exception as e:
        print("Error:", e)
        return 1e9  # 如果发生错误，返回一个大的值，避免继续优化




# ------------------- 主PSO优化循环 -------------------
def TACPSO_Levy(N, Max_iteration, lb, ub, dim):
    wMax = 0.9
    wMin = 0.4
    beta = 1.5
    levy_scale = 0.01
    vel = 0.3 * np.random.rand(N, dim)
    pos = np.random.rand(N, dim) * (np.array(ub) - np.array(lb)) + np.array(lb)
    pBest = pos.copy()
    pBestScore = np.ones(N) * np.inf
    gBest = np.zeros(dim)
    gBestScore = np.inf
    cg_curve = np.zeros((Max_iteration, dim))
    score_curve = np.zeros(Max_iteration)

    for l in range(Max_iteration):
        c1 = 0.5 + 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)
        c2 = 2.2 - 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)
        w = wMax - (l+1) * ((wMax - wMin) / Max_iteration)
        for i in range(N):
            pos[i] = np.clip(pos[i], lb, ub)
            fitness = objective_function(pos[i])
            if fitness < pBestScore[i]:
                pBestScore[i] = fitness
                pBest[i] = pos[i]
            if fitness < gBestScore:
                gBestScore = fitness
                gBest = pos[i].copy()
        for i in range(N):
            for j in range(dim):
                vel[i, j] = (w * vel[i, j]
                             + c1 * np.random.rand() * (pBest[i, j] - pos[i, j])
                             + c2 * np.random.rand() * (gBest[j] - pos[i, j]))
            levy_step = levy_scale * levy_flight(beta, dim)
            pos[i] += vel[i] + levy_step
            pos[i] = np.clip(pos[i], lb, ub)
        cg_curve[l] = gBest.copy()
        score_curve[l] = gBestScore
        print(f'Iter {l+1}/{Max_iteration} | Best val_loss={gBestScore:.5f} | '
              f'filter={gBest[0]:.1f}, units={gBest[1]:.1f}, dropout={gBest[2]:.4f}, lr={gBest[3]:.6f}')
    return gBest, gBestScore, cg_curve, score_curve


# ------------------- 参数范围和主运行体 -------------------
if __name__ == "__main__":
    N = 30             # 种群数量
    Max_iteration = 50  # 迭代次数
    lb = [32, 32, 32, 0.2, 1e-5]  # filter_num, units1, units2, dropout, lr 下限
    ub = [256, 256, 256, 0.6, 1e-3]  # filter_num, units1, units2, dropout, lr 上限
    dim = 5  # 维度为5，因为你有5个超参数

    best_param, best_loss, param_curve, loss_curve = TACPSO_Levy(N, Max_iteration, lb, ub, dim)
    print("\n=== 调优结果 ===")
    print(f"最优 filter_num: {int(round(best_param[0]))}")
    print(f"最优 units1: {int(round(best_param[1]))}")
    print(f"最优 units2: {int(round(best_param[2]))}")
    print(f"最优 dropout: {best_param[3]:.4f}")
    print(f"最优 learning rate: {best_param[4]:.6f}")
    print(f"最优验证集loss: {best_loss:.5f}")
    print("请将这5个参数写入你的主模型文件。")

    # ---- 可选：绘制参数收敛曲线 ----
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes[0,0].plot(param_curve[:,0]); axes[0,0].set_title('filter_num'); axes[0,0].set_xlabel('iter')
    axes[0,1].plot(param_curve[:,1]); axes[0,1].set_title('units1'); axes[0,1].set_xlabel('iter')
    axes[1,0].plot(param_curve[:,2]); axes[1,0].set_title('units2'); axes[1,0].set_xlabel('iter')
    axes[1,1].plot(param_curve[:,3]); axes[1,1].set_title('dropout'); axes[1,1].set_xlabel('iter')
    axes[1,2].plot(param_curve[:,4]); axes[1,2].set_title('learning-rate'); axes[1,2].set_xlabel('iter')
    plt.tight_layout()
    plt.show()


