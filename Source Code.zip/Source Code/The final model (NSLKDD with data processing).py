

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.metrics import matthews_corrcoef, cohen_kappa_score

from keras.models import Model
from keras.layers import Input, Dense, Dropout, Activation, LSTM, Bidirectional, Conv1D
from keras.layers import BatchNormalization, MaxPooling1D, Reshape, Multiply
import tensorflow as tf

# ------------- 工具函数 -------------------

def one_hot(df_train, cols):
    for col in cols:
        dummies = pd.get_dummies(df_train[col], prefix=col).astype('float32')
        df_train = pd.concat([df_train.drop(col, axis=1), dummies], axis=1)
    return df_train

def normalize(df_train, cols):
    result = df_train.copy()
    for col in cols:
        min_val = df_train[col].min()
        max_val = df_train[col].max()
        if max_val > min_val:
            result[col] = (df_train[col] - min_val) / (max_val - min_val)
    return result

def map_class(val):
    for k, v in class_map.items():
        if val in v:
            return k
    return "Normal"

def attention_weights(inputs, num_filters):
    attention_score = Dense(1, activation='sigmoid')(inputs)
    attention_score = Reshape((-1,))(attention_score)
    attention_weights = tf.nn.softmax(attention_score, axis=-1)
    return attention_weights
# 3、5、9
def build_model(input_shape):
    inputs = Input(shape=input_shape)
    conv5 = Conv1D(64, kernel_size=3, padding="same", activation="relu")(inputs)
    conv10 = Conv1D(64, kernel_size=5, padding="same", activation="relu")(inputs)
    conv15 = Conv1D(64, kernel_size=9, padding="same", activation="relu")(inputs)

    attention_5 = attention_weights(conv5, 64)
    attention_10 = attention_weights(conv10, 64)
    attention_15 = attention_weights(conv15, 64)

    attention_5 = tf.expand_dims(attention_5, axis=-1)
    attention_10 = tf.expand_dims(attention_10, axis=-1)
    attention_15 = tf.expand_dims(attention_15, axis=-1)

    conv5_weighted = Multiply()([conv5, attention_5])
    conv10_weighted = Multiply()([conv10, attention_10])
    conv15_weighted = Multiply()([conv15, attention_15])

    concatenated = tf.concat([conv5_weighted, conv10_weighted, conv15_weighted], axis=-1)

    x = MaxPooling1D(pool_size=5)(concatenated)
    x = BatchNormalization()(x)
    x = Bidirectional(LSTM(60, return_sequences=False))(x)
    x = Reshape((120, 1))(x)
    x = MaxPooling1D(pool_size=5)(x)
    x = BatchNormalization()(x)
    x = Bidirectional(LSTM(130, return_sequences=False))(x)
    x = Dropout(0.32)(x)

    x = Dense(5)(x)
    x = Activation('softmax')(x)

    model = Model(inputs=inputs, outputs=x)
    model.compile(loss='categorical_crossentropy',
                  optimizer=tf.keras.optimizers.Adam(learning_rate=0.002),
                  metrics=['accuracy'])
    return model

# ------------- 主程序 --------------------

# 定义列名
col_names = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land',
             'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
             'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
             'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
             'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
             'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
             'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
             'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
             'dst_host_same_src_port_rate', 'dst_host_srv_diff_host_rate',
             'dst_host_serror_rate', 'dst_host_srv_serror_rate',
             'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'subclass', 'difficulty_level']

# 读取数据
df_train = pd.read_csv('KDDTrain+.txt', header=None, names=col_names)
df_test = pd.read_csv('KDDTest+.txt', header=None, names=col_names)

# 删除无用列
df_train.drop('difficulty_level', axis=1, inplace=True)
df_test.drop('difficulty_level', axis=1, inplace=True)

# 合并数据进行统一处理
data_all = pd.concat([df_train, df_test])
data_all = one_hot(data_all, ['protocol_type', 'service', 'flag'])

labels = data_all.pop('subclass')

# 标签映射字典
class_map = {
    "DoS": ["apache2", "back", "land", "neptune", "mailbomb", "pod", "processtable",
            "smurf", "teardrop", "udpstorm", "worm"],
    "Probe": ["ipsweep", "mscan", "nmap", "portsweep", "saint", "satan"],
    "U2R": ["buffer_overflow", "loadmodule", "perl", "ps", "rootkit", "sqlattack", "xterm"],
    "R2L": ["ftp_write", "guess_passwd", "httptunnel", "imap", "multihop", "named",
            "phf", "sendmail", "Snmpgetattack", "spy", "snmpguess", "warezclient",
            "warezmaster", "xlock", "xsnoop"],
    "Normal": []
}

mapped_labels = labels.apply(map_class)

data_all = normalize(data_all, data_all.columns)
data_all = pd.concat([data_all, mapped_labels.rename("Class")], axis=1).copy()

X = data_all.drop('Class', axis=1)
y = data_all['Class']

# 固定比例划分：70%训练，30%测试（分层采样）
X_train, X_test, y_train_raw, y_test_raw = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

X_train = X_train.values.reshape(-1, X.shape[1], 1)
X_test = X_test.values.reshape(-1, X.shape[1], 1)

y_train = pd.get_dummies(y_train_raw).values
y_test = pd.get_dummies(y_test_raw).values

model = build_model((X.shape[1], 1))
model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=50, batch_size=32, verbose=1)

pred_prob = model.predict(X_test)
pred_labels = np.argmax(pred_prob, axis=1)
true_labels = np.argmax(y_test, axis=1)

acc_m = accuracy_score(true_labels, pred_labels)
prec_m = precision_score(true_labels, pred_labels, average='weighted', zero_division=0)
recall_m = recall_score(true_labels, pred_labels, average='weighted', zero_division=0)
f1_m = f1_score(true_labels, pred_labels, average='weighted', zero_division=0)

cm_m = confusion_matrix(true_labels, pred_labels)
FP_m = cm_m.sum(axis=0) - np.diag(cm_m)
FN_m = cm_m.sum(axis=1) - np.diag(cm_m)
TN_m = cm_m.sum() - (cm_m.sum(axis=0) + cm_m.sum(axis=1) - np.diag(cm_m))
TP_m = np.diag(cm_m)

FPR = FP_m / (FP_m + TN_m + 1e-10)
FNR = FN_m / (FN_m + TP_m + 1e-10)
MCC = matthews_corrcoef(true_labels, pred_labels)
Kappa = cohen_kappa_score(true_labels, pred_labels)

print("=== Metrics on test set ===")
print(f"Accuracy: {acc_m:.4f}")
print(f"Precision: {prec_m:.4f}")
print(f"Recall: {recall_m:.4f}")
print(f"F1-score: {f1_m:.4f}")
print(f"FPR: {np.mean(FPR):.4f}")
print(f"FNR: {np.mean(FNR):.4f}")
print(f"MCC: {MCC:.4f}")
print(f"Kappa: {Kappa:.4f}")

# 混淆矩阵概率化
classes = list(pd.get_dummies(y).columns)
cm_prob = cm_m.astype('float32') / cm_m.sum(axis=1)[:, np.newaxis]


plt.figure(figsize=(10, 8))
ax = sns.heatmap(cm_prob, annot=True, fmt='.3f', cmap='Blues', cbar=True,
                 xticklabels=classes, yticklabels=classes)
for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.0)  # 边框粗细
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.xticks(rotation=45)
plt.show()
