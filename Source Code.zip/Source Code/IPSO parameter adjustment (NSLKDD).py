import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from tensorflow.keras.models import Model
from tensorflow.keras.layers import (Input, Dense, Dropout, Activation, LSTM, Bidirectional,
                                     Conv1D, BatchNormalization, MaxPooling1D, Reshape, Multiply)
from tcn import TCN
import matplotlib.pyplot as plt

# ------------------- 1. 数据预处理：NSL-KDD -------------------
col_names = ['duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes', 'land',
             'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
             'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
             'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
             'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
             'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
             'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
             'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
             'dst_host_same_src_port_rate', 'dst_host_srv_diff_host_rate',
             'dst_host_serror_rate', 'dst_host_srv_serror_rate',
             'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'subclass', 'difficulty_level']

# 读取数据
df_train = pd.read_csv('KDDTrain+.txt', header=None, names=col_names)
df_test = pd.read_csv('KDDTest+.txt', header=None, names=col_names)

df_train.drop('difficulty_level', axis=1, inplace=True)
df_test.drop('difficulty_level', axis=1, inplace=True)

# 合并方便统一预处理
data_all = pd.concat([df_train, df_test], ignore_index=True)

# 独热编码
def one_hot(df, cols):
    for col in cols:
        dummies = pd.get_dummies(df[col], prefix=col).astype('float32')
        df = pd.concat([df.drop(col, axis=1), dummies], axis=1)
    return df

data_all = one_hot(data_all, ['protocol_type', 'service', 'flag'])
print(data_all.shape)


labels = data_all.pop('subclass')

# 子类->大类标签映射
class_map = {
    "DoS": ["apache2", "back", "land", "neptune", "mailbomb", "pod", "processtable", "smurf", "teardrop", "udpstorm", "worm"],
    "Probe": ["ipsweep", "mscan", "nmap", "portsweep", "saint", "satan"],
    "U2R": ["buffer_overflow", "loadmodule", "perl", "ps", "rootkit", "sqlattack", "xterm"],
    "R2L": ["ftp_write", "guess_passwd", "httptunnel", "imap", "multihop", "named", "phf", "sendmail", "snmpgetattack", "spy", "snmpguess", "warezclient", "warezmaster", "xlock", "xsnoop"],
    "Normal": []
}

def map_class(val):
    for k, v in class_map.items():
        if val in v:
            return k
    return "Normal"
mapped_labels = labels.apply(map_class)

# 归一化
def normalize(df, cols):
    result = df.copy()
    for col in cols:
        min_val = df[col].min()
        max_val = df[col].max()
        if max_val > min_val:
            result[col] = (df[col] - min_val) / (max_val - min_val)
    return result
data_all = normalize(data_all, data_all.columns)
data_all = pd.concat([data_all, mapped_labels.rename("Class")], axis=1).copy()

# 划分特征与标签
X = data_all.drop('Class', axis=1)
y = data_all['Class']
y_encoded = pd.get_dummies(y).values
num_classes = y_encoded.shape[1]


X_small, _, y_small, _ = train_test_split(X, y_encoded, train_size=0.999, stratify=y)
X_train, X_val, y_train, y_val = train_test_split(X_small, y_small, train_size=0.7, stratify=y_small)
input_shape = (X_train.shape[1], 1)
X_train_reshaped = X_train.values.reshape(-1, X_train.shape[1], 1)
X_val_reshaped = X_val.values.reshape(-1, X_val.shape[1], 1)

# ------------------- 2. 神经网络结构与PSO目标函数 -------------------
def attention_weights(inputs, num_filters):
    attention_score = Dense(1, activation='sigmoid')(inputs)
    attention_score = Reshape((-1,))(attention_score)
    attention_weights = tf.nn.softmax(attention_score, axis=-1)
    return attention_weights

def build_model(input_shape, num_classes, filter_num, units1, units2, dropout, lr):
    filter_num = int(round(filter_num))  # 确保为整数
    units1 = int(round(units1))
    units2 = int(round(units2))

    inputs = Input(shape=input_shape)

    # 使用不同大小的卷积核：3、5、9
    conv3 = Conv1D(filter_num, kernel_size=3, padding="same", activation="relu")(inputs)
    conv7 = Conv1D(filter_num, kernel_size=9, padding="same", activation="relu")(inputs)
    conv5 = Conv1D(filter_num, kernel_size=5, padding="same", activation="relu")(inputs)

    # 为每个卷积层的输出应用注意力机制
    attention_3 = attention_weights(conv3, filter_num)
    attention_7 = attention_weights(conv7, filter_num)
    attention_5 = attention_weights(conv5, filter_num)

    # 扩展 attention 的维度，使其形状与卷积输出兼容
    attention_3 = tf.expand_dims(attention_3, axis=-1)
    attention_7 = tf.expand_dims(attention_7, axis=-1)
    attention_5 = tf.expand_dims(attention_5, axis=-1)

    # 加权卷积输出
    conv3_weighted = Multiply()([conv3, attention_3])
    conv7_weighted = Multiply()([conv7, attention_7])
    conv5_weighted = Multiply()([conv5, attention_5])

    # 合并加权后的卷积输出
    concatenated = tf.concat([conv3_weighted, conv7_weighted, conv5_weighted], axis=-1)

    # 后续的卷积池化、LSTM层等处理
    x = MaxPooling1D(pool_size=5)(concatenated)  # 池化层
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(units1, return_sequences=False))(x)  # 第一个BiLSTM层
    x = Reshape((2*units1, 1))(x)  # 重塑张量形状
    x = MaxPooling1D(pool_size=5)(x)  # 第二层池化
    x = BatchNormalization()(x)  # 批标准化
    x = Bidirectional(LSTM(units2, return_sequences=False))(x)  # 第二个BiLSTM层
    x = Dropout(dropout)(x)  # Dropout防止过拟合

    # 输出层，类别数为 num_classes
    x = Dense(num_classes)(x)
    x = Activation('softmax')(x)  # Softmax激活函数

    # 定义模型
    model = Model(inputs=inputs, outputs=x)
    model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
                  metrics=['accuracy'])
    return model


# Levy飞行扰动
def levy_flight(beta, dim):
    sigma_u = (np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) /
               (np.math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = np.random.randn(dim) * sigma_u
    v = np.random.randn(dim)
    step = u / (np.abs(v) ** (1 / beta))
    return step


def objective_function(params):
    filter_num = int(round(params[0]))  # 卷积过滤器数量
    units1 = int(round(params[1]))  # 第一个BiLSTM单元数量
    units2 = int(round(params[2]))  # 第二个BiLSTM单元数量
    dropout = float(params[3])  # Dropout比例
    lr = float(params[4])  # 学习率

    try:
        tf.keras.backend.clear_session()  # 清理之前的模型会话，释放内存
        model = build_model(input_shape, num_classes, filter_num, units1, units2, dropout, lr)  # 构建模型

        # 训练模型，epochs设置为50，可以根据需要调整
        hist = model.fit(X_train_reshaped, y_train, epochs=50, batch_size=32,
                         validation_data=(X_val_reshaped, y_val), verbose=1)

        val_loss = hist.history['val_loss'][-1]  # 获取最后一个epoch的测试集损失

        return val_loss  # 最小化测试集的loss

    except Exception as e:
        print("Error:", e)
        return 1e9  # 如果发生错误，返回一个大的值，避免继续优化



# ------------------- 3. TACPSO_Levy主PSO优化循环 -------------------
def TACPSO_Levy(N, Max_iteration, lb, ub, dim):
    wMax = 0.9
    wMin = 0.4
    beta = 1.5
    levy_scale = 0.01
    vel = 0.3 * np.random.rand(N, dim)
    pos = np.random.rand(N, dim) * (np.array(ub) - np.array(lb)) + np.array(lb)
    pBest = pos.copy()
    pBestScore = np.ones(N) * np.inf
    gBest = np.zeros(dim)
    gBestScore = np.inf
    cg_curve = np.zeros((Max_iteration, dim))
    score_curve = np.zeros(Max_iteration)

    for l in range(Max_iteration):
        c1 = 0.5 + 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)
        c2 = 2.2 - 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)
        w = wMax - (l+1) * ((wMax - wMin) / Max_iteration)
        for i in range(N):
            pos[i] = np.clip(pos[i], lb, ub)
            fitness = objective_function(pos[i])
            if fitness < pBestScore[i]:
                pBestScore[i] = fitness
                pBest[i] = pos[i]
            if fitness < gBestScore:
                gBestScore = fitness
                gBest = pos[i].copy()
        for i in range(N):
            for j in range(dim):
                vel[i, j] = (w * vel[i, j]
                             + c1 * np.random.rand() * (pBest[i, j] - pos[i, j])
                             + c2 * np.random.rand() * (gBest[j] - pos[i, j]))
            levy_step = levy_scale * levy_flight(beta, dim)
            pos[i] += vel[i] + levy_step
            pos[i] = np.clip(pos[i], lb, ub)
        cg_curve[l] = gBest.copy()
        score_curve[l] = gBestScore
        print(f'Iter {l+1}/{Max_iteration} | Best val_loss={gBestScore:.5f} | '
              f'filter={gBest[0]:.1f}, units={gBest[1]:.1f}, dropout={gBest[2]:.4f}, lr={gBest[3]:.6f}')
    return gBest, gBestScore, cg_curve, score_curve

# ------------------- 4. 主程序入口 -------------------
if __name__ == "__main__":
    N = 30             # 种群数量
    Max_iteration = 50  # 迭代次数
    lb = [32, 32, 32, 0.2, 1e-5]  # filter_num, units1, units2, dropout, lr 下限
    ub = [256, 256, 256, 0.6, 1e-3]  # filter_num, units1, units2, dropout, lr 上限
    dim = 5  # 维度为5，因为你有5个超参数

    best_param, best_loss, param_curve, loss_curve = TACPSO_Levy(N, Max_iteration, lb, ub, dim)
    print("\n=== 调优结果 ===")
    print(f"最优 filter_num: {int(round(best_param[0]))}")
    print(f"最优 units1: {int(round(best_param[1]))}")
    print(f"最优 units2: {int(round(best_param[2]))}")
    print(f"最优 dropout: {best_param[3]:.4f}")
    print(f"最优 learning rate: {best_param[4]:.6f}")
    print(f"最优验证集loss: {best_loss:.5f}")
    print("请将这4个参数写入你的主模型文件。")

    # ---- 可选：绘制参数收敛曲线 ----
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes[0,0].plot(param_curve[:,0]); axes[0,0].set_title('filter_num'); axes[0,0].set_xlabel('iter')
    axes[0,1].plot(param_curve[:,1]); axes[0,1].set_title('units1'); axes[0,1].set_xlabel('iter')
    axes[1,0].plot(param_curve[:,2]); axes[1,0].set_title('units2'); axes[1,0].set_xlabel('iter')
    axes[1,1].plot(param_curve[:,3]); axes[1,1].set_title('dropout'); axes[1,1].set_xlabel('iter')
    axes[1,2].plot(param_curve[:,4]); axes[1,2].set_title('learning-rate'); axes[1,2].set_xlabel('iter')
    plt.tight_layout()
    plt.show()

