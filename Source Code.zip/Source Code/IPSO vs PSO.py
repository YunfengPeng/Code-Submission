import numpy as np
import matplotlib.pyplot as plt


# Ackley 函数，常用的测试优化算法的目标函数
def ackley(x):
    n = len(x)
    sum_sq = np.sum(x**2)
    sum_cos = np.sum(np.cos(2 * np.pi * x))
    return -20 * np.exp(-0.2 * np.sqrt(sum_sq / n)) - np.exp(sum_cos / n) + 20 + np.e


# 标准 PSO 实现
def pso_standard(N, Max_iteration, lb, ub, dim, objective_function):
    wMax = 0.9  # 最大惯性权重
    wMin = 0.4  # 最小惯性权重
    c1 = 2.05  # 自我认知因子
    c2 = 2.05  # 社会认知因子

    # 初始化粒子的位置和速度
    pos = np.random.uniform(low=lb, high=ub, size=(N, dim))  # 粒子位置
    vel = np.random.uniform(low=-1, high=1, size=(N, dim))  # 粒子速度
    pBest = pos.copy()  # 粒子历史最佳位置
    pBestScore = np.ones(N) * np.inf  # 粒子历史最佳得分
    gBest = np.zeros(dim)  # 全局最佳位置
    gBestScore = np.inf  # 全局最佳得分

    eval_count = 0  # 记录函数评估次数
    best_scores = []  # 用于存储每次迭代的最优值

    # 迭代过程
    for l in range(Max_iteration):
        w = wMax - (l / Max_iteration) * (wMax - wMin)  # 渐变惯性权重

        # 评估适应度并更新历史最优解
        for i in range(N):
            pos[i] = np.clip(pos[i], lb, ub)  # 限制粒子位置在边界内
            fitness = objective_function(pos[i])  # 计算当前粒子的适应度
            eval_count += 1  # 每次调用目标函数，评估次数加 1
            if fitness < pBestScore[i]:  # 更新粒子历史最优
                pBestScore[i] = fitness
                pBest[i] = pos[i]
            if fitness < gBestScore:  # 更新全局最优
                gBestScore = fitness
                gBest = pos[i].copy()

        # 更新粒子速度和位置
        for i in range(N):
            vel[i] = (w * vel[i] + c1 * np.random.rand() * (pBest[i] - pos[i])
                      + c2 * np.random.rand() * (gBest - pos[i]))  # 速度更新
            pos[i] = pos[i] + vel[i]  # 位置更新
            pos[i] = np.clip(pos[i], lb, ub)  # 限制粒子位置在边界内

        # 记录最优值
        best_scores.append(gBestScore)

        print(f'Iter {l + 1}/{Max_iteration} | Best val_loss={gBestScore:.5f} | Function Evaluations={eval_count}')

    return gBest, gBestScore, eval_count, best_scores

# Levy Flight 算法
def levy_flight(beta, dim):
    """
    Levy Flight 算法
    :param beta: Levy Flight 的控制参数
    :param dim: 搜索空间的维度
    :return: Levy 飞行步长
    """
    sigma = (np.math.gamma(1 + beta) * np.sin(np.pi * beta / 2) /
             (np.math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
    u = np.random.normal(0, sigma, dim)
    v = np.random.normal(0, 1, dim)
    step = u / (np.abs(v) ** (1 / beta))
    return step

# TACPSO with Levy Flight
def TACPSO_Levy(N, Max_iteration, lb, ub, dim, objective_function):
    """
    TACPSO with Levy Flight
    :param N: 粒子数目
    :param Max_iteration: 最大迭代次数
    :param lb: 搜索空间的下界
    :param ub: 搜索空间的上界
    :param dim: 问题的维度
    :param objective_function: 目标函数
    :return: 最优解、最优得分
    """
    wMax = 0.9  # 最大惯性权重
    wMin = 0.4  # 最小惯性权重
    beta = 1.5  # Levy flight 参数
    levy_scale = 0.01  # Levy flight 扩展因子
    vel = 0.3 * np.random.rand(N, dim)  # 初始化速度
    pos = np.random.rand(N, dim) * (np.array(ub) - np.array(lb)) + np.array(lb)  # 初始化位置
    pBest = pos.copy()  # 粒子历史最佳位置
    pBestScore = np.ones(N) * np.inf  # 粒子历史最佳得分
    gBest = np.zeros(dim)  # 全局最佳位置
    gBestScore = np.inf  # 全局最佳得分

    eval_count = 0  # 记录函数评估次数
    best_scores = []  # 用于存储每次迭代的最优值

    # 迭代优化
    for l in range(Max_iteration):
        c1 = 0.5 + 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)  # 自我认知系数
        c2 = 2.2 - 2 * np.exp(-(4 * (l+1) / Max_iteration) ** 2)  # 社会认知系数
        w = wMax - (l+1) * ((wMax - wMin) / Max_iteration)  # 惯性权重

        for i in range(N):
            pos[i] = np.clip(pos[i], lb, ub)  # 限制粒子位置在边界内
            fitness = objective_function(pos[i])  # 计算当前粒子的适应度
            eval_count += 1  # 每次调用目标函数，评估次数加 1
            if fitness < pBestScore[i]:  # 更新粒子历史最优
                pBestScore[i] = fitness
                pBest[i] = pos[i]
            if fitness < gBestScore:  # 更新全局最优
                gBestScore = fitness
                gBest = pos[i].copy()

        # 更新粒子速度和位置
        for i in range(N):
            for j in range(dim):
                # 速度更新公式
                vel[i, j] = (w * vel[i, j]
                             + c1 * np.random.rand() * (pBest[i, j] - pos[i, j])
                             + c2 * np.random.rand() * (gBest[j] - pos[i, j]))

            # 引入 Levy Flight 步长
            levy_step = levy_scale * levy_flight(beta, dim)  # 生成 Levy Flight 步长
            pos[i] += vel[i] + levy_step  # 更新粒子位置
            pos[i] = np.clip(pos[i], lb, ub)  # 限制粒子位置在边界内

        # 记录最优值
        best_scores.append(gBestScore)

        print(f'Iter {l + 1}/{Max_iteration} | Best val_loss={gBestScore:.5f} | Function Evaluations={eval_count}')

    return gBest, gBestScore, eval_count, best_scores

# 比较两种算法的性能
def compare_algorithms():
    # 参数设置
    N = 10  # 粒子数目
    Max_iteration = 500  # 最大迭代次数
    lb = -5.12  # 搜索空间下界
    ub = 5.12  # 搜索空间上界
    dim = 10  # 问题维度

    # 运行标准 PSO
    pso_best, pso_best_score, pso_eval_count, pso_best_scores = pso_standard(N, Max_iteration, lb, ub, dim, ackley)

    # 运行 TACPSO_Levy
    tacpso_best, tacpso_best_score, tacpso_eval_count, tacpso_best_scores = TACPSO_Levy(N, Max_iteration, lb, ub, dim, ackley)

    # 打印结果
    print(f"PSO 最佳结果: {pso_best_score}, 函数评估次数: {pso_eval_count}")
    print(f"IPSO 最佳结果: {tacpso_best_score}, 函数评估次数: {tacpso_eval_count}")

    # 绘制收敛曲线
    plt.plot(range(1, Max_iteration + 1), pso_best_scores, label="PSO")
    plt.plot(range(1, Max_iteration + 1), tacpso_best_scores, label="IPSO")
    plt.xlabel('Iteration')
    plt.ylabel('Best val_loss')
    plt.legend()
    plt.show()

# 运行比较
compare_algorithms()
